<?php
/*
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
*/
    $data = json_decode(file_get_contents("php://input"));

    if($data->bloggerId1!=""){
        $str = "INSERT INTO blogposts (bloggerId, userName, header, hindiHeader, germanHeader, content, hindiContent, germanContent) VALUES ('$data->bloggerId1','$data->bloggername1','$data->header','$data->hindiHeader','$data->germanHeader','$data->content','$data->hindiContent','$data->germanContent')";
        $con = mysqli_connect("localhost","root","","cms");
		$result = mysqli_query($con,$str) or
        die(json_encode(["text"=>"Update Failed" , "class"=>"danger","error"=>mysqli_error($con)]));
        echo json_encode (["text"=>"Update successful", "class"=>"success","error"=>"false"]);
    }
    else{
        echo json_encode(["text"=>"Update Failed" , "class"=>"danger", "error"=>"Request is Empty."]);
    }
?>