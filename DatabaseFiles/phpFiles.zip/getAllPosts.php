<?php
	ini_set('display_errors',1);
	error_reporting(E_ALL);
	//header('Access-Control-Allow-Origin: *');
	//header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	//header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
	
	$array = [];
	$str = "SELECT * FROM blogposts";
	$con = mysqli_connect("localhost","root","","cms");
	$result = mysqli_query($con, $str) or
	die (json_encode(["text"=>"No Data","class"=>"danger","error"=>mysqli_error($con)]));
	while($row = mysqli_fetch_assoc($result)){
		array_push($array,json_encode($row));		
		//echo json_encode($row);
	}
	echo json_encode($array);
	//print_r($array);
?>