<?php

	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

    $data = json_decode(file_get_contents("php://input"));

    if($data->bloggerId1!=""){
        $str = "UPDATE blogposts SET header='$data->header',hindiHeader='$data->hindiHeader',germanHeader='$data->germanHeader',content='$data->content',hindiContent='$data->hindiContent',germanContent='$data->germanContent' WHERE ID='$data->blogId1' && bloggerId='$data->bloggerId1';";
        $con = mysqli_connect("localhost","root","","cms");
		$result = mysqli_query($con,$str) or
        die(json_encode(["text"=>"Update Failed" , "class"=>"danger","error"=>mysqli_error($con)]));
        echo json_encode (["text"=>"Update successful", "class"=>"success","error"=>"false"]);
    }
    else{
        echo json_encode(["text"=>"Update Failed" , "class"=>"danger", "error"=>"Request is Empty."]);
    }
?>