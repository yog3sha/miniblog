<?php
$text="this is a sample text";
$from="en";	//
$to="fr";
$gt=file_get_contents("http://ajax.ajax.googleapis.com/ajax/services/language/translate
?>
<!--
/*
https://www.google.co.in/search?q=english+to+hindi+translation&oq=english+to+&aqs=chrome.2.69i57j0j35i39l2j0l2.4710j1j7&sourceid=chrome&ie=UTF-8

<textarea class="tw-ta tw-text-large" id="tw-source-text-ta" autocapitalize="off" autocomplete="off" autocorrect="off" rows="1" spellcheck="false" jsaction="focus:tob.pon;blur:tob.pof;tob.poc" lang="en" dir="ltr"></textarea>

<pre class="tw-data-text tw-ta tw-text-large" id="tw-target-text"  data-fulltext="" dir="ltr"><span lang="hi">नमस्ते</span></pre>

Google Translate:
https://translate.google.co.in/?um=1&ie=UTF-8&hl=en&client=tw-ob#en/hi/Hello
<textarea id="source" name="text" wrap="SOFT" tabindex="0" dir="ltr" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" class="goog-textarea short_text" style="box-sizing: border-box; overflow: auto hidden; padding-right: 20px;"></textarea>

<span id="result_box" class="short_text" lang="hi"><span>नमस्ते</span></span> */ -->