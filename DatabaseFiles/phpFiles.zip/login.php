
<?php

	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

    $data = json_decode(file_get_contents("php://input"));
	$array = [];
    if($data->email!=""){
        $str = "SELECT bloggerId, FirstName FROM bloggers WHERE (Email='". $data->email ."' AND Password='".$data->password."')";
        $con = mysqli_connect("localhost","root","","cms");
		$result = mysqli_query($con,$str) or
        die(json_encode(["text"=>"Login Failed" , "class"=>"danger","error"=>mysqli_error($con)]));
		$row = mysqli_fetch_assoc($result);
		array_push($array,json_encode($row));
		echo json_encode($array);
        //echo json_encode (["text"=>"Login successful", "class"=>"success","error"=>"false"]);
    }
    else{
        echo json_encode(["text"=>"Login Failed!!!" , "class"=>"danger", "error"=>"Request is Empty."]);
    }
?>