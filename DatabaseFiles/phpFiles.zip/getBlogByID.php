<?php	
	$data = json_decode(file_get_contents("php://input"));
	$str = "SELECT * FROM blogPosts WHERE (bloggerId = '$data->bloggerId' && Id='$data->blogId')";
	$con = mysqli_connect("localhost","root","","cms");
	$result = mysqli_query($con, $str) or
	die (json_encode(["text"=>"No Data","class"=>"danger","error"=>mysqli_error($con)]));
	echo json_encode(mysqli_fetch_assoc($result));	
?>