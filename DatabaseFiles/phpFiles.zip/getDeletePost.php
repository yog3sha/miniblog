<?php	
	$data = json_decode(file_get_contents("php://input"));
	$str = "DELETE FROM users WHERE id = '$data'";
	$con = mysqli_connect("localhost","root","","users");
	$result = mysqli_query($con, $str) or
	die (json_encode(["text"=>"No Data","class"=>"danger","error"=>mysqli_error($con)]));
	echo 'Record Deleted Successfully!';
?>