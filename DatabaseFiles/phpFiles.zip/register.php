<?php

	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

    $data = json_decode(file_get_contents("php://input"));

    if($data->email != ""){
        $str = "INSERT INTO bloggers (FirstName,LastName,City,Contact,Email,Password) VALUES ('$data->firstName','$data->lastName','Mumbai','$data->contact','$data->email','$data->password')";
        $con = mysqli_connect("localhost","root","","cms");
		$result = mysqli_query($con,$str) or
        die(json_encode(["text"=>"Update Failed" , "class"=>"danger","error"=>mysqli_error($con)]));
        echo json_encode (["text"=>"Registrarion successful", "class"=>"success","error"=>"false"]);
    }
    else{
        echo json_encode(["text"=>"Regisration Failed" , "class"=>"danger", "error"=>"Request is Empty."]);
    }
?>